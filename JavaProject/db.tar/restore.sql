--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.4
-- Dumped by pg_dump version 12.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'WIN1252';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "fundementals-of-java";
--
-- Name: fundementals-of-java; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "fundementals-of-java" WITH TEMPLATE = template0 ENCODING = 'WIN1252' LC_COLLATE = 'Spanish_Colombia.1252' LC_CTYPE = 'Spanish_Colombia.1252';


ALTER DATABASE "fundementals-of-java" OWNER TO postgres;

\connect -reuse-previous=on "dbname='fundementals-of-java'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'WIN1252';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Choices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Choices" (
    id bigint NOT NULL,
    choice character varying(500)
);


ALTER TABLE public."Choices" OWNER TO postgres;

--
-- Name: Choices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Choices" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Choices_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Questions" (
    id bigint NOT NULL,
    question character varying(500),
    answer character varying(500),
    difficulty bigint
);


ALTER TABLE public."Questions" OWNER TO postgres;

--
-- Name: Questions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Questions" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Questions_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Quizes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Quizes" (
    id bigint NOT NULL,
    title character varying(500)
);


ALTER TABLE public."Quizes" OWNER TO postgres;

--
-- Name: Quizes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Quizes" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Quizes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Relation_Questions_Choices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Relation_Questions_Choices" (
    id_question bigint,
    id_choice bigint
);


ALTER TABLE public."Relation_Questions_Choices" OWNER TO postgres;

--
-- Name: Relation_Questions_Topics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Relation_Questions_Topics" (
    id_question bigint,
    id_topic bigint
);


ALTER TABLE public."Relation_Questions_Topics" OWNER TO postgres;

--
-- Name: Relation_Quizes_Questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Relation_Quizes_Questions" (
    id_quiz bigint,
    id_question bigint
);


ALTER TABLE public."Relation_Quizes_Questions" OWNER TO postgres;

--
-- Name: Student_Answers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Student_Answers" (
    id_student bigint,
    id_question bigint,
    id_quiz bigint,
    answer character varying(500)
);


ALTER TABLE public."Student_Answers" OWNER TO postgres;

--
-- Name: Student_Quizes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Student_Quizes" (
    id_student bigint,
    id_quiz bigint,
    grade bigint
);


ALTER TABLE public."Student_Quizes" OWNER TO postgres;

--
-- Name: Students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Students" (
    id bigint NOT NULL,
    first_name character varying(500),
    last_name character varying(500),
    dob date,
    gender character varying(500)
);


ALTER TABLE public."Students" OWNER TO postgres;

--
-- Name: Students_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Students" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Students_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Topics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Topics" (
    id bigint NOT NULL,
    topic character varying(500)
);


ALTER TABLE public."Topics" OWNER TO postgres;

--
-- Name: Topics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Topics" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Topics_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: Choices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Choices" (id, choice) FROM stdin;
\.
COPY public."Choices" (id, choice) FROM '$$PATH$$/2865.dat';

--
-- Data for Name: Questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Questions" (id, question, answer, difficulty) FROM stdin;
\.
COPY public."Questions" (id, question, answer, difficulty) FROM '$$PATH$$/2867.dat';

--
-- Data for Name: Quizes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Quizes" (id, title) FROM stdin;
\.
COPY public."Quizes" (id, title) FROM '$$PATH$$/2869.dat';

--
-- Data for Name: Relation_Questions_Choices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Relation_Questions_Choices" (id_question, id_choice) FROM stdin;
\.
COPY public."Relation_Questions_Choices" (id_question, id_choice) FROM '$$PATH$$/2871.dat';

--
-- Data for Name: Relation_Questions_Topics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Relation_Questions_Topics" (id_question, id_topic) FROM stdin;
\.
COPY public."Relation_Questions_Topics" (id_question, id_topic) FROM '$$PATH$$/2872.dat';

--
-- Data for Name: Relation_Quizes_Questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Relation_Quizes_Questions" (id_quiz, id_question) FROM stdin;
\.
COPY public."Relation_Quizes_Questions" (id_quiz, id_question) FROM '$$PATH$$/2873.dat';

--
-- Data for Name: Student_Answers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Student_Answers" (id_student, id_question, id_quiz, answer) FROM stdin;
\.
COPY public."Student_Answers" (id_student, id_question, id_quiz, answer) FROM '$$PATH$$/2874.dat';

--
-- Data for Name: Student_Quizes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Student_Quizes" (id_student, id_quiz, grade) FROM stdin;
\.
COPY public."Student_Quizes" (id_student, id_quiz, grade) FROM '$$PATH$$/2875.dat';

--
-- Data for Name: Students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Students" (id, first_name, last_name, dob, gender) FROM stdin;
\.
COPY public."Students" (id, first_name, last_name, dob, gender) FROM '$$PATH$$/2876.dat';

--
-- Data for Name: Topics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Topics" (id, topic) FROM stdin;
\.
COPY public."Topics" (id, topic) FROM '$$PATH$$/2878.dat';

--
-- Name: Choices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Choices_id_seq"', 113, true);


--
-- Name: Questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Questions_id_seq"', 95, true);


--
-- Name: Quizes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Quizes_id_seq"', 41, true);


--
-- Name: Students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Students_id_seq"', 2, true);


--
-- Name: Topics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Topics_id_seq"', 77, true);


--
-- Name: Choices Choices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Choices"
    ADD CONSTRAINT "Choices_pkey" PRIMARY KEY (id);


--
-- Name: Questions Questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Questions"
    ADD CONSTRAINT "Questions_pkey" PRIMARY KEY (id);


--
-- Name: Students Students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Students"
    ADD CONSTRAINT "Students_pkey" PRIMARY KEY (id);


--
-- Name: Topics Topics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Topics"
    ADD CONSTRAINT "Topics_pkey" PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

